import db
from objects import QB, QBs

def add_QB(QBs):
    first_name = input("First name: ").title()
    last_name = input("Last name: ").title()
    passing_yards = get_passing_yards()
    touchdowns = get_touchdowns()
    interceptions = get_interceptions()
    attempts = get_attempts()
    completions = get_completions(attempts)
    number = get_depth_chart_number(QBs, "Depth Chart Number: ")

    qb = QB(first_name, last_name, passing_yards, touchdowns, interceptions,
            completions, attempts, number)
    QBs.add(qb)
    db.add_QB(qb)
    print(f"{QB.lastName} was added.\n")

def get_passing_yards():
    while True:
        try:
            passing_yards = int(input("Passing Yards: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if passing_yards < 0 or passing_yards > 7500:
            print("Invalid entry. Must be from 0 to 7500.")
        else:
            return passing_yards

def get_touchdowns():
    while True:
        try:
            touchdowns = int(input("Touchdowns: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if touchdowns < 0 or touchdowns > 100:
            print("Invalid entry. Must be from 0 to 100.")
        else:
            return touchdowns

def get_interceptions():
    while True:
        try:
            interceptions = int(input("Interceptions: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if interceptions < 0 or interceptions > 50:
            print("Invalid entry. Must be from 0 to 50.")
        else:
            return interceptions

def get_attempts():
    while True:
        try:
            attempts = int(input("Attempts: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if attempts < 0 or attempts > 1000:
            print("Invalid entry. Must be from 0 to 1000.")
        else:
            return attempts
        
def get_completions(attempts):
    while True:
        try:
            completions = int(input("Completions: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if completions < 0 or completions > attempts:
            print(f"Invalid entry. Must be from 0 to {completions}.")
        else:
            return completions

def get_depth_chart_number(QBs, prompt):
    while True:
        try:
            number = int(input(prompt))
        except ValueError:
            print("Invalid integer. Please try again.")
        else:
            return number

def delete_QB(QBs):
    number = get_depth_chart_number(QBs, "Number: ")
    qb = QBs.remove(number)
    db.delete_QB(QB)
    print(f"{QB.lastName} was deleted. \n")

def move_QB(QBs):
    old_number = get_depth_chart_number(QBs, "Current Number: ")
    QB = QBs.get(old_number)
    print(" was selected.")
    new_number = get_depth_chart_number(QBs, "New Number: ")

    QBs.move(old_number, new_number)
    db.update_depth_chart_number(QBs)
    print(" was moved.\n")

def edit_QB_stats(QBs):
    number = get_depth_chart_number(QBs, "Depth Chart Number: ")
    QB = QBs.get(number)
    print("You selected ")
    passingYards = get_passing_yards()
    touchdowns = get_touchdowns()
    interceptions = get_interceptions()
    attempts = get_attempts()
    completions = get_completions(attempts)
    db.update_QB(QB)
    db.update_depth_chart_number(QB)
    print(" was updated. \n")

def display_depth_chart(QBs):
    if QBs == None:
        print("There are currently no QBs on the depth chart.")
    else:
        print(f"{'':3}{'QB':35}")
        print("-" * 64)
        for QB in QBs:
            print(f"{QB.depthChartNumber:<3d}{QB.fullName:35}{QB.passingYards:5d}" + \
                  f"{QB.touchdowns:3d}{QB.interceptions:3d}{QB.completions:4d}{QB.attempts:4d}" + \
                  f"{QB.completionPercentage:5.1f}")
    print()

def display_separator():
    print("=" * 64)

def display_title():
    print("                Football QBs Depth Chart")

def display_menu():
    print("MENU OPTIONS")
    print("1 - Display depth chart")
    print("2 - Add QB")
    print("3 - Remove QB")
    print("4 - Move QB")
    print("5 - Edit QB stats")
    print("6 - Exit program")
    print()

def main():
    display_separator()
    display_title()
    display_menu()
    db.connect()
    QBs = db.get_QBs()
    if QBs == None:
        QBs = objects.QBs

    display_separator()

    while True:
        try:
            option = int(input("Menu option: "))
        except ValueError:
            option = -1

        if option == 1:
            display_depth_chart(QBs)
        elif option == 2:
            add_QB(QBs)
            QBs = db.get_QBs()
        elif option == 3:
            delete_QB(QBs)
        elif option == 4:
            move_QB(QBs)
        elif option == 5:
            edit_QB_stats(QBs)
        elif option == 6:
            db.close()
            print("Bye!")
            break
        else:
            print("Not a valid option. Please try again.\n")
            display_menu()

if __name__ == "__main__":
    main()
          
