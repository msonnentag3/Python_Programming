import sqlite3
from contextlib import closing
from objects import QB, QBs

conn = None

def connect():
    global conn
    if not conn:
        DB_FILE = "football_QBs.sqlite"
        conn = sqlite3.connect(DB_FILE)
        conn.row_factory = sqlite3.Row
def close():
    if conn:
        conn.close()

def make_QB(row):
    return QB(row["firstName"], row["lastName"], row["passingYards"],
              row["touchdowns"], row["interceptions"], row["completions"],
              row["attempts"], row["playerID"], row["depthChartNumber"])

def get_QBs():
    query = '''SELECT firstName, lastName, passingYards, touchdowns, interceptions,
                      completions, attempts, playerID, depthChartNumber
                FROM QBs
                ORDER BY playerID'''
    with closing(conn.cursor()) as c:
        c.execute(query)
        results = c.fetchall()

    players = QBs()
    for row in results:
        QB = make_QB(row)
        players.add(QB)
    return players

def get_QB(id):
    query = '''SELECT playerID, firstName, lastName, passingYards, touchdowns, interceptions,
                      completions, attempts, depthChartNumber
                FROM QBs
                WHERE playerID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(query, (id,))
        row = c.fetchone()
        if row:
            QB = make_QB(row)
            return QB
        else:
            return None

def add_QB(QB):
    sql = '''INSERT INTO QBs
                (firstName, lastName, passingYards, touchdowns, interceptions,
                 completions, attempts, depthChartNumber)
                VALUES
                    (?, ?, ?, ?, ?, ?, ?, ?)'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (QB.firstName, QB.lastName, QB.passingYards, QB.touchdowns,
                        QB.interceptions, QB.completions, QB.attempts, QB.depthChartNumber))
        conn.commit()

def delete_QB(QB):
    sql ='''DELETE FROM QBs
            WHERE playerID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (QB.playerID,))
        conn.commit()

def update_depth_chart_number(QB):
    for num, QB in enumerate(QB, start=1):
        QB.depthChartNumber = num
        sql = '''UPDATE QBs
                 SET depthChartNumber = ?
                 WHERE playerID = ?'''
        with closing(conn.cursor()) as c:
            c.execute(sql, (QB.depthChartNumber, QB.playerID))
    conn.commit()

def update_QB(QB):
    sql = '''UPDATE QBs
             SET passingYards = ?, touchdowns = ?, interceptions = ?,
             completions = ?, attempts = ?
             WHERE playerID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (QB.passingYards, QB.touchdowns, QB.interceptions,
                        QB.completions, QB.attempts, QB.playerID))
        conn.commit()

def main():
    connect()
    qbs = get_QBs()
    for QB in QBs:
        print(QB.firstName, QB.lastName, QB.passingYards, QB.touchdowns, QB.interceptions,
              QB.completions, QB.attempts, QB.completionPercentage)

if __name__ == "__main__":
    main()
