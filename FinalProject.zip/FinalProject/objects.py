from dataclasses import dataclass

@dataclass
class QB:
    firstName:str = ""
    lastName:str = ""
    passingYards:int = 0
    touchdowns:int = 0
    interceptions:int = 0
    completions:int = 0
    attempts:int = 0
    depthChartNumber:int = 0
    playerID:int = 0

    @property
    def fullName(self):
        return f"{self.firstName} {self.lastName}"

    @property
    def completionPercentage(self):
        try:
            compPer = self.completions / self.attempts
            return round(compPer, 1)
        except ZeroDivisionError:
            return 0.0

class QBs:
    def __init__(self):
        self.__list = []

    @property
    def count(self):
        return len(self.__list)

    def add(self, QB):
        return self.__list.append(QB)

    def remove(self, number):
        return self.__list.pop(number-1)

    def get(self, number):
        self.__list[number-1]

    def set(self, number, QB):
        self.__list[number-1] = QB

    def move(self, oldNumber, newNumber):
        QB = self.__list.pop(oldNumber-1)
        self.__list.insert(newNumber-1, QB)

    def __iter__(self):
        for QB in self.__list:
            yield QB

def main():
    qbs = QBs()
    for QB in QBs:
        print(QB.fullName, QB.passingYards, QB.touchdowns, QB.interceptions,
              QB.completions, QB.attempts, QB.completionPercentage)
    print("Bye!")

if __name__ == "__main__":
    main()
